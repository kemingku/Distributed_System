package edu.buffalo.cse.cse486586.simpledynamo;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.os.AsyncTask;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.util.Pair;

import java.io.BufferedReader;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StreamCorruptedException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

import static edu.buffalo.cse.cse486586.simpledynamo.Message.MessageType.RECOVERY_REPLY;
import static edu.buffalo.cse.cse486586.simpledynamo.Message.NodeType.COORDINATOR;
import static edu.buffalo.cse.cse486586.simpledynamo.Message.NodeType.REPLICA;
import static edu.buffalo.cse.cse486586.simpledynamo.SimpleDynamoProvider.ALL;
import static edu.buffalo.cse.cse486586.simpledynamo.SimpleDynamoProvider.LOCAL;
import static edu.buffalo.cse.cse486586.simpledynamo.SimpleDynamoProvider.genHash;

public class Dynamo {
    // Number of replicas including the coordinator
    private static final int N = 3;
    // the actual ring, hashed and sorted using SHA1
    private static final List<String> RING;
    // Number of distinct nodes
    private static String[] REMOTE_NODES = {"11108", "11112", "11116", "11120", "11124"};

    public static final int SERVER_PORT = 10000;
    private static final String TAG = Dynamo.class.getName();
    public static final int TIMEOUT = 1500; // ms
    private static Dynamo INSTANCE = null;

    // used to aggregate query replies
    private static Map<UUID, Map<String, Message.Value>> REPLIES = new ConcurrentHashMap<>();
    // used to track request/response sessions and wait.
    private static Map<UUID, Semaphore> SESSIONS = new ConcurrentHashMap<>();
    private static AtomicLong version = new AtomicLong(1);
    private final Context context;
    private final DBHelper db;
    private String myId;
    private String myPort;
    private static volatile UUID recoverySessionId;

    // Pre-computed hashes
    private static final Map<String, String> NODES_HASH; // <port,  hash>
    private static final Map<String, String> HASH_NODE; // <hash,  port>
    private static final CopyOnWriteArraySet<String> OFFLINE_NODES = new CopyOnWriteArraySet<>();

    static {
        RING = new ArrayList<String>(5) {
            // NOTE: this is terrible!, violates interface contract.
            // TODO: Use a Ring-buffer.
            @Override
            public String get(int index) {
                return (index < 0) ? super.get(size() + index) : super.get(index % size());
            }

            @Override
            public String toString() {
                if (isEmpty()) {
                    return "[]";
                }

                StringBuilder buffer = new StringBuilder();
                buffer.append('[');
                Iterator<String> it = iterator();
                while (it.hasNext()) {
                    String next = it.next();
                    if (next != null) {
                        buffer.append(HASH_NODE.get(next));
                    }
                    if (it.hasNext()) {
                        buffer.append(" -> "); // pretty print
                    }
                }
                buffer.append(']');
                return buffer.toString();
            }
        };

        NODES_HASH = new HashMap<>(5);
        HASH_NODE = new HashMap<>(5);
        for (String node : REMOTE_NODES) {
            String hash = genHash(String.valueOf(Integer.valueOf(node) / 2));

            RING.add(hash);

            NODES_HASH.put(node, hash);
            HASH_NODE.put(hash, node);
        }

        Collections.sort(RING);
        Log.d(TAG, "Dynamo Ring: " + RING);
    }

    private Dynamo(Context context) {
        this.context = context;
        this.db = DBHelper.db(context);

        TelephonyManager tel = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        this.myId = tel.getLine1Number().substring(tel.getLine1Number().length() - 4);
        this.myPort = String.valueOf((Integer.parseInt(myId) * 2));
    }

    public static Dynamo get(Context context) {
        if (INSTANCE == null) {
            synchronized (Dynamo.class) {
                INSTANCE = new Dynamo(context);
                INSTANCE.start();
                Log.w(TAG, "Service started: " + INSTANCE.myPort);
            }
        }
        return INSTANCE;
    }

    public void start() {
        try {
            ServerSocket serverSocket = new ServerSocket(SERVER_PORT);
            serverSocket.setReuseAddress(true);
            new ServerTask(context)
                    .executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
            db.drop();
            // Start recovery
            Message recoverRequest = track(Message.recoverRequest(myPort), 4);
            List<String> recoveryNodes = DynamoRing.recoveryNodes(myPort);
            sendTo(recoveryNodes, recoverRequest);
            recoverySessionId = recoverRequest.getSessionId();
        } catch (IOException e) {
            Log.e(TAG, "Can't create a ServerSocket");
        }
    }


    private void dbInsert(Map.Entry<String, Message.Value> entry) {
        ContentValues cv = new ContentValues(1);
        cv.put("key", entry.getKey());
        cv.put("value", entry.getValue().getValue());
        cv.put("version", entry.getValue().getVersion());
        db.insert(cv);
        Log.d(TAG, "Inserted: " + cv);
    }

    private void dbInsert(Message message) {
        ContentValues cv = new ContentValues(1);
        cv.put("key", message.getKey());
        cv.put("value", message.getValue());
        cv.put("version", message.getVersion());
        db.insert(cv);
        Log.d(TAG, "Inserted: " + cv);
    }


    public void insert(ContentValues values) {
        waitForRecovery();

        String key = values.getAsString("key");
        String value = values.getAsString("value");

        String coordinator = DynamoRing.coordinatorForKey(key);
        List<String> replicasForCoordinator = DynamoRing.replicasForCoordinator(coordinator);
        long version = newVersionNumber(key);

        if (coordinator.equals(myPort)) {
            values.put("version", version);
            db.insert(values);
            Log.v(TAG, "Coordinator Inserted " + values.toString());

            // now replicate, wait for ack from last replica/partition (chain replication)
            Message replicaInsert1 = Message.insert(myPort, key, value, REPLICA, version);
            Message replicaInsert2 = track(replicaInsert1.ack(true));
            sendTo(replicasForCoordinator.get(1), replicaInsert2);
            sendTo(replicasForCoordinator.get(0), replicaInsert1);

            Log.d(TAG, "Sending INSERT to replicas:" + replicasForCoordinator + " " + replicaInsert1);

            // wait for ACK
            if (waitForCompletion(replicaInsert2.getSessionId(), TIMEOUT * 2, TimeUnit.MILLISECONDS)) {
                Log.d(TAG, "Received INSERT ACK from Replicas");
            } else {
                Log.w(TAG, "Replica INSERT TimedOut " + replicaInsert1);
            }
        } else {
            Message insert = track(Message.insert(myPort, key, value, COORDINATOR, version));

            sendTo(coordinator, insert);
            Log.d(TAG, "Sending INSERT to Coordinator:" + coordinator + " " + insert);

            // wait for ACK
            if (waitForCompletion(insert.getSessionId(), TIMEOUT * 2, TimeUnit.MILLISECONDS)) {
                Log.d(TAG, "Received INSERT ACK from Coordinator");
            } else {
                Log.d(TAG, "Coordinator INSERT TimedOut " + insert);
                // timed out, i.e coordinator is down
                // forward to replicas.

                Message replicaInsert1 = Message.insert(myPort, key, value, REPLICA, version);
                Message replicaInsert2 = track(replicaInsert1.ack(true));

                sendTo(replicasForCoordinator.get(1), replicaInsert2);
                sendTo(replicasForCoordinator.get(0), replicaInsert1);

                Log.d(TAG, "Forward INSERT to replicas " + replicasForCoordinator + " " + replicaInsert1);

                // wait for ACK
                if (waitForCompletion(replicaInsert2.getSessionId(), TIMEOUT * 2, TimeUnit.MILLISECONDS)) {
                    Log.d(TAG, "Received INSERT ACK from Replicas");
                } else {
                    Log.e(TAG, "Replica INSERT TimedOut " + replicaInsert1);

                    // try to send again to coordinator:
                    sendTo(coordinator, insert);
                }
            }
        }
    }

    public long delete(String key) {
        switch (key) {
            case ALL: {
                db.drop();
                sendTo(DynamoRing.allOtherNodes(myPort), Message.delete(myPort, ALL, Message.NodeType.ALL));
                break;
            }
            case LOCAL: {
                return db.drop();
            }
            default: {
                String coordinator = DynamoRing.coordinatorForKey(key);

                if (coordinator.equals(myPort)) {
                    db.delete(key);

                    List<String> replicas = DynamoRing.replicasForCoordinator(coordinator);
                    sendTo(replicas, Message.delete(myPort, key, REPLICA));
                } else {
                    Message delete = Message.delete(myPort, key, COORDINATOR);
                    SESSIONS.put(delete.getSessionId(), new Semaphore(0));

                    sendTo(coordinator, delete);

                    // wait for ACK
                    if (waitForCompletion(delete.getSessionId(), TIMEOUT, TimeUnit.MILLISECONDS)) {
                        Log.d(TAG, "Received DELETE ACK from Coordinator");
                    } else {
                        // timed out, i.e coordinator is down
                        // forward to replicas.

                        List<String> replicas = DynamoRing.replicasForCoordinator(coordinator);
                        sendTo(replicas, delete.nodeType(REPLICA));
                    }
                }
                break;
            }
        }
        return 0L;
    }

    public Cursor query(String key) {
        waitForRecovery();

        switch (key) {
            case ALL: {
                Log.d(TAG, "QUERY ALL: " + key);
                MatrixCursor result = new MatrixCursor(new String[]{"key", "value"});

                Message query = track(Message.queryRequest(myPort, ALL, Message.NodeType.ALL), 4);

                try (Cursor cursor = db.all()) {
                    while (cursor.moveToNext()) {
                        result.addRow(new String[]{cursor.getString(0), cursor.getString(1)});
                    }
                }

                sendTo(DynamoRing.allOtherNodes(myPort), query);

                if (waitForCompletion(query.getSessionId(), 10, TimeUnit.SECONDS)) {
                    Log.d(TAG, "Query ALL completed");
                } else {
                    Log.w(TAG, "Timed out while querying ALL");
                }

                for (Map.Entry<String, Message.Value> entry : REPLIES.get(query.getSessionId()).entrySet()) {
                    result.addRow(new String[]{entry.getKey(), entry.getValue().getValue()});
                }

                return result;
            }
            case LOCAL: {
                Log.d(TAG, "QUERY @ LOCAL");
                MatrixCursor result = new MatrixCursor(new String[]{"key", "value"});
                try {
                    Thread.sleep(10);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                try (Cursor cursor = db.all()) {
                    while (cursor.moveToNext()) {
                        result.addRow(new String[]{cursor.getString(0), cursor.getString(1)});
                    }
                }
                return result;
            }
            default: {
                Log.d(TAG, "QUERY for key " + key);

                MatrixCursor result = new MatrixCursor(new String[]{"key", "value"});

                String coordinator = DynamoRing.coordinatorForKey(key);
                List<String> replicas = DynamoRing.replicasForCoordinator(coordinator);

                Message replicaQuery2 = track(Message.queryRequest(myPort, key, REPLICA));
                sendTo(replicas.get(1), replicaQuery2);

                Message coordinatorQuery = track(Message.queryRequest(myPort, key, COORDINATOR));
                sendTo(coordinator, coordinatorQuery);

                Message replicaQuery1 = track(Message.queryRequest(myPort, key, REPLICA));
                sendTo(replicas.get(0), replicaQuery1);

                // wait for reply from responsible nodes
                if (waitForCompletion(replicaQuery2.getSessionId(), TIMEOUT, TimeUnit.MILLISECONDS)) {
                    Log.d(TAG, "Received last replica");
                } else {
                    Log.w(TAG, "TimedOut while waiting for Query Replies from last replica");
                }

                if (waitForCompletion(coordinatorQuery.getSessionId(), TIMEOUT, TimeUnit.MILLISECONDS)) {
                    Log.d(TAG, "Received Query Replies from Coordinator");
                } else {
                    Log.w(TAG, "TimedOut while waiting for Query Replies from Coordinator");
                }

                if (waitForCompletion(replicaQuery1.getSessionId(), TIMEOUT, TimeUnit.MILLISECONDS)) {
                    Log.d(TAG, "Received Query Replies from first replica");
                } else {
                    Log.w(TAG, "TimedOut while waiting from first replica");
                }

                Set<UUID> querySessions = new LinkedHashSet<>(3);
                querySessions.add(replicaQuery2.getSessionId());
                querySessions.add(coordinatorQuery.getSessionId());
                querySessions.add(replicaQuery1.getSessionId());

                Set<Message.Value> valueSet = new HashSet<>(3);
                long latestVersion = Long.MIN_VALUE;
                String latestValue = "";

                for (UUID session : querySessions) {
                    for (Message.Value v : REPLIES.get(session).values()) {
                        if (v.getVersion() > latestVersion) {
                            latestVersion = v.getVersion();
                            latestValue = v.getValue();
                        }
                        valueSet.add(v);
                    }
                }

                if (valueSet.size() > 1) {
                    Log.d(TAG, key + " Latest value: " + latestValue + " from: " + valueSet);
                }
                result.addRow(new String[]{key, latestValue});
                if (latestVersion > Long.MIN_VALUE) {
                    sendTo(DynamoRing.preferenceListForKey(key), Message.insert(myPort, key, latestValue, Message.NodeType.UPDATE, latestVersion));
                }
                return result;
            }
        }
    }

    private synchronized void waitForRecovery() {
        if (recoverySessionId != null) {
            Log.d(TAG, "WAITING FOR RECOVERY");
            if (waitForCompletion(recoverySessionId, 5, TimeUnit.SECONDS)) {
                Log.d(TAG, "RECOVERY COMPLETED");
            } else {
                Log.d(TAG, "RECOVERY TIMED-OUT");
            }
            recoverySessionId = null;
        }
    }

    public boolean waitForCompletion(UUID session, long time, TimeUnit timeUnit) {
        Log.d(TAG, "waitForCompletion " + session + " : " + time + " : " + timeUnit);
        try {
            long start = System.nanoTime();
            if (SESSIONS.get(session).tryAcquire(time, timeUnit)) {
                Log.d(TAG, "waitForCompletion success took: " + TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - start) + "ms.");
                return true;
            } else {
                Log.w(TAG, "Timed out while waiting for: " + session);
            }
        } catch (InterruptedException e) {
            Log.e(TAG, "Interrupted while waiting for: " + session);
        }
        return false;
    }


    private Message track(Message in, int replyCount) {
        SESSIONS.put(in.getSessionId(), new Semaphore(-1 * (replyCount - 1), true)); // replyCount->permits
        REPLIES.put(in.getSessionId(), new ConcurrentHashMap<String, Message.Value>(0));
        return in;
    }

    private Message track(Message in) {
        SESSIONS.put(in.getSessionId(), new Semaphore(0, true));
        REPLIES.put(in.getSessionId(), new ConcurrentHashMap<String, Message.Value>(0));
        return in;
    }

    private void sendAck(Message message) {
        String fromPort = message.getFromPort();
        Message ack = message.messageType(Message.MessageType.ACK).fromPort(myPort);
        sendTo(fromPort, ack);
        Log.d(TAG, "Sent ACK to:" + fromPort + ": " + message);
    }

    private long newVersionNumber(String key) {
        long versionL = 1;
        try (Cursor cursor = db.version(key)) {
            while (cursor.moveToNext()) {
                versionL = cursor.getLong(0) + 1;
                Log.d(TAG, "NEW VERSION: " + versionL + " " + key);
            }
        }
        return versionL;
    }

    private void sendTo(Collection<String> nodes, Message p) {
        for (String node : nodes) {
            sendTo(node, p);
        }
    }

    public void handle(Message message) {
        switch (message.getMessageType()) {
            case ACK: {
                Log.d(TAG, "Received ACK " + message);
                SESSIONS.get(message.getSessionId()).release();
                break;
            }
            case INSERT: {
                switch (message.getNodeType()) {
                    case COORDINATOR: {
                        // Insert
                        message = message.version(newVersionNumber(message.getKey())).fromPort(myPort);
                        dbInsert(message);
                        Log.v(TAG, "Coordinator Inserted " + message.getValue());

                        // Forward to replicas, by using chain replication
                        List<String> replicas = DynamoRing.replicasForCoordinator(myPort);

                        Message replicaInsert1 = message.nodeType(REPLICA);
                        Message replicaInsert2 = track(replicaInsert1.ack(true));
                        sendTo(replicas.get(1), replicaInsert2);
                        sendTo(replicas.get(0), replicaInsert1);

                        // wait for ACK from last replica. i.e chain replication
                        if (waitForCompletion(replicaInsert2.getSessionId(), TIMEOUT, TimeUnit.MILLISECONDS)) {
                            Log.d(TAG, "Received INSERT ACK from last replica");
                        } else {
                            Log.w(TAG, "Replica INSERT TimedOut " + replicaInsert2);
                        }
                        break;
                    }
                    default: {
                        if (message.isAck()) {
                            // Send ack if requested.
                            sendAck(message);
                        }
                        boolean fromCoordinator = DynamoRing.coordinatorForKey(message.getKey()).equals(message.getFromPort());
                        if (!fromCoordinator && message.getNodeType() == REPLICA) {
                            message = message.version(newVersionNumber(message.getKey()));
                        }

                        // Insert
                        dbInsert(message);
                        Log.v(TAG, "Replica Inserted " + message);
                        break;
                    }
                }
                break;
            }
            case DELETE: {
                switch (message.getNodeType()) {
                    case COORDINATOR: {
                        // Send ack.
                        sendAck(message);

                        List<String> replicas = DynamoRing.replicasForCoordinator(myPort);
                        sendTo(replicas, message.fromPort(myPort).nodeType(REPLICA));
                        break;
                    }
                }
                switch (message.getKey()) {
                    case ALL: {
                        Log.d(TAG, "DELETE ALL: " + message);
                        db.drop();
                        break;
                    }
                    default: {
                        Log.d(TAG, "DELETE : " + message);
                        db.delete(message.getKey());
                        break;
                    }
                }
                break;
            }
            case QUERY_REQUEST: {
                waitForRecovery();

                switch (message.getKey()) {
                    case ALL: {
                        Log.d(TAG, "QUERY REQUEST ALL " + message);

                        Message queryReply = message.fromPort(myPort).messageType(Message.MessageType.QUERY_REPLY);
                        try (Cursor cursor = db.all()) {
                            while (cursor.moveToNext()) {
                                queryReply.getQueryResults().put(cursor.getString(0), new Message.Value(cursor.getString(1), cursor.getLong(2)));
                            }
                        }
                        sendTo(message.getFromPort(), queryReply);

                        break;
                    }
                    default: {
                        Log.d(TAG, "QUERY REQUEST Key " + message);

                        Message queryReply = message.fromPort(myPort).messageType(Message.MessageType.QUERY_REPLY);
                        try (Cursor cursor = db.query(message.getKey())) {
                            while (cursor.moveToNext()) {
                                queryReply.getQueryResults().put(cursor.getString(0), new Message.Value(cursor.getString(1), cursor.getLong(cursor.getColumnIndex("version"))));
                            }
                        }
                        if (queryReply.getQueryResults().isEmpty()) {
                            Log.w(TAG, message.getNodeType() + " Watch out for inconsistencies!");
                        } else {
                            sendTo(message.getFromPort(), queryReply);
                        }
                        break;
                    }
                }
                break;
            }
            case QUERY_REPLY: {
                Log.d(TAG, "QUERY REPLY:" + message);
                REPLIES.get(message.getSessionId()).putAll(message.getQueryResults());
                SESSIONS.get(message.getSessionId()).release();
                break;
            }
            case RECOVERY_REQUEST: {
                waitForRecovery();

                Log.d(TAG, "RECOVERY REQUEST from:" + message.getFromPort() + ": " + message);
                Message recoveryReply = message.fromPort(myPort).messageType(RECOVERY_REPLY);
                long start = System.nanoTime();
                try (Cursor cursor = db.all()) {
                    while (cursor.moveToNext()) {
                        String key = cursor.getString(0);
                        if (DynamoRing.preferenceListForKey(key).contains(message.getFromPort())) {
                            recoveryReply.getQueryResults().put(key, new Message.Value(cursor.getString(1), cursor.getLong(cursor.getColumnIndex("version"))));
                        }
                    }
                }
                sendTo(message.getFromPort(), recoveryReply);

                Log.d(TAG, "RECOVERY REPLY TIME took: " + TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - start));

                break;
            }
            case RECOVERY_REPLY: {
                Log.d(TAG, "RECOVERY REPLY from:" + message.getFromPort() + ": " + message);
                for (Map.Entry<String, Message.Value> entry : message.getQueryResults().entrySet()) {
                    long version = Long.MIN_VALUE;
                    try (Cursor cursor = db.query(entry.getKey())) {
                        while (cursor.moveToNext()) {
                            version = cursor.getLong(cursor.getColumnIndex("version"));
                        }
                    }
                    if (entry.getValue().getVersion() >= version) {
                        dbInsert(entry);
                    }
                }
                SESSIONS.get(message.getSessionId()).release();
                break;
            }
        }

    }

    private void sendTo(String node, Message p) {
        Log.d(TAG, "Sending to: " + node + " : " + p);
        new ClientTask().executeOnExecutor(AsyncTask.SERIAL_EXECUTOR, new Pair<>(node, p));
    }

    private static class DynamoRing {


        public static LinkedHashSet<String> preferenceListForKey(String key) {
            LinkedHashSet<String> s = new LinkedHashSet<>(N + 1);
            String coordinator = coordinatorForKey(key);
            s.add(coordinator);
            s.addAll(replicasForCoordinator(coordinator));
            return s;
        }

        public static LinkedHashSet<String> preferenceListForNode(String node) {
            LinkedHashSet<String> s = new LinkedHashSet<>(N);
            s.add(node);
            s.addAll(replicasForCoordinator(node));
            return s;
        }

        public static String coordinatorForKey(String key) {
            String keyHash = genHash(key);

            for (String nodeHash : RING) {
                if (keyHash.compareTo(nodeHash) <= 0) {
                    return HASH_NODE.get(nodeHash);
                }
            }
            return HASH_NODE.get(RING.get(0));
        }

        public static List<String> replicasForCoordinator(String coordinator) {
            int coordinatorIndex = RING.indexOf(NODES_HASH.get(coordinator));
            List<String> replicas = new ArrayList<>(N - 1);
            for (int i = 1; i <= (N - 1); i++) {
                String node = HASH_NODE.get(RING.get(coordinatorIndex + i));
                replicas.add(node);
            }
            return replicas;
        }

        public static List<String> recoveryNodes(String port) {
            int index = RING.indexOf(NODES_HASH.get(port));
            List<String> nodes = new ArrayList<>(4);
            // add successors/replicas
            for (int i = 1; i <= (N - 1); i++) {
                String node = HASH_NODE.get(RING.get(index + i));
                nodes.add(node);
            }
            // add predecessors
            for (int i = (N - 1); i > 0; i--) {
                String node = HASH_NODE.get(RING.get(index - i));
                nodes.add(node);
            }
            Log.d(TAG, "Recovery nodes for: " + port + " : " + nodes);
            return nodes;
        }

        public static List<String> allOtherNodes(String me) { // all other nodes except this node
            List<String> others = new ArrayList<>(5);
            for (String node : REMOTE_NODES) {
                if (!node.equals(me)) {
                    others.add(node);
                }
            }
            return others;
        }

        public static int liveNodeCount() {
            return REMOTE_NODES.length - OFFLINE_NODES.size();
        }

        public static boolean isOffline(String node) {
            return OFFLINE_NODES.contains(node);
        }

        public static void markOnline(String node) {
            if (OFFLINE_NODES.contains(node)) {
                Log.e(TAG, "ONLINE: node :" + node);
                OFFLINE_NODES.remove(node);
            }
        }

        public static void markOffline(String node) {
            if (OFFLINE_NODES.add(node)) {
                Log.e(TAG, "OFFLINE: node :" + node);
            }
        }

        public static int liveNodeCount(List<String> nodes) {
            int online = 0;
            for (String node : nodes) {
                if (!isOffline(node)) {
                    online++;
                }
            }
            return online;
        }
    }


    private class ServerTask extends AsyncTask<ServerSocket, StringBuilder, Void> {
        private final Context context;
        public static final int TIMEOUT = 800;

        public ServerTask(Context context) {
            this.context = context;
        }

        @Override
        protected Void doInBackground(ServerSocket... sockets) {
            ServerSocket serverSocket = sockets[0];
            String port = "0";
            while (true) {
                try {
                    StringBuilder total = new StringBuilder(200);
                    Socket socket = serverSocket.accept();
                    port = socket.getRemoteSocketAddress().toString();
                    socket.setSoTimeout(TIMEOUT);
                    BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    String receive;
                    while ((receive = in.readLine()) != null) {
                        total.append(receive);
                    }
                    in.close();
                    socket.close();
                    if (total.length() > 0) {
                        publishProgress(total);
                    }

                } catch (UnknownHostException e) {
                    Log.e(TAG, "ServerTask UnknownHostException", e);
                } catch (NullPointerException e) {
                    Log.e(TAG, "ServerTask NullPointerException", e);
                } catch (SocketTimeoutException | StreamCorruptedException | EOFException e) {
                    Log.e(TAG, "ServerTask socket timeout at: " + port, e);
                } catch (Exception e) {
                    Log.e(TAG, "ServerTask Exception", e);
                }
            }
        }

        @Override
        protected void onProgressUpdate(StringBuilder... values) {
            try {
                for (final StringBuilder payloadString : values) {
                    String json = payloadString.toString();
                    if (!json.isEmpty()) {
                        final Message message = Message.deserialize(json);
                        if (message != null) {
                            new Thread(new Runnable() { // NOTE: we do not need AsyncTask here, because we do not interact with UI
                                @Override               // use a thread pool/Executor?
                                public void run() {
                                    Dynamo.get(context).handle(message);
                                }
                            }).start();
                        }
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "ServerTask onProgressUpdate Exception", e);
            }
        }
    }

    private class ClientTask extends AsyncTask<Pair<String, Message>, Void, Set<Result>> {
        public static final int TIMEOUT = 800;

        @Override
        protected Set<Result> doInBackground(Pair<String, Message>... payloads) { // <to, payload>
            Set<Result> results = new HashSet<>();

            for (Pair<String, Message> payloadPair : payloads) {
                String node = payloadPair.first;
                String serialized = payloadPair.second.serialize();
                if (serialized != null && !serialized.isEmpty()) {
                    try (Socket socket = new Socket()) {
                        socket.connect(new InetSocketAddress("10.0.2.2", Integer.parseInt(node)),TIMEOUT);
                        OutputStream out = socket.getOutputStream();
                        Thread.sleep(10);
                        out.write(serialized.getBytes(StandardCharsets.UTF_8));
                        out.flush();
                        results.add(new Result(true, node));
                        out.close();
                    } catch (Exception e) {
                        results.add(new Result(false, node));
                        Log.e(TAG, "ClientTask socket Exception" + " while sending to " + node, e); // offline?
                    }
                } else {
                    Log.d(TAG, "EMPTY payload not sent: " + serialized);
                }
            }
            return results;
        }

        @Override
        protected void onPostExecute(Set<Result> results) {
            for (Result r : results) {
                if (r.success) {
                    DynamoRing.markOnline(r.node);
                } else {
                    DynamoRing.markOffline(r.node);
                }
            }
        }

    }

    private class Result {
        private boolean success;
        private String node;

        public Result(boolean success, String node) {
            this.success = success;
            this.node = node;
        }
    }


}
